import React from 'react';
import { ExternalLink, Database, Brain, Stethoscope } from 'lucide-react';

const Projects = () => {
  return (
    <section id="projects" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Featured Project
          </h2>
          <div className="w-20 h-1 bg-blue-600 rounded-full mx-auto mb-8"></div>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-3xl overflow-hidden shadow-2xl">
            {/* Project Image/Visual */}
            <div className="relative h-64 md:h-80 bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center">
              <div className="text-center text-white">
                <div className="flex justify-center space-x-6 mb-6">
                  <Database className="w-12 h-12 opacity-80" />
                  <Brain className="w-12 h-12 opacity-80" />
                  <Stethoscope className="w-12 h-12 opacity-80" />
                </div>
                <h3 className="text-2xl md:text-3xl font-bold mb-2">
                  Healthcare ML System
                </h3>
                <p className="text-blue-100 text-lg">
                  Machine Learning + Big Data Solution
                </p>
              </div>
              <div className="absolute inset-0 bg-black/10"></div>
            </div>

            {/* Project Content */}
            <div className="p-8 md:p-12">
              <h3 className="text-2xl md:text-3xl font-bold text-gray-900 mb-6">
                Disease Diagnosis and Drug Prescription using Machine Learning
              </h3>
              
              <p className="text-lg text-gray-600 leading-relaxed mb-8">
                A comprehensive machine learning and big data-based healthcare system that automates disease diagnosis and drug prescription workflows. This innovative solution combines advanced algorithms with medical data analysis to provide accurate, efficient healthcare recommendations.
              </p>

              <div className="flex flex-wrap gap-3 mb-8">
                {['Machine Learning', 'Big Data', 'Healthcare', 'Automation', 'Data Analysis'].map((tech) => (
                  <span
                    key={tech}
                    className="px-4 py-2 bg-blue-100 text-blue-700 rounded-full font-medium text-sm"
                  >
                    {tech}
                  </span>
                ))}
              </div>

              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2 text-gray-600">
                  <Brain className="w-5 h-5" />
                  <span className="font-medium">AI-Powered Diagnosis</span>
                </div>
                <div className="flex items-center space-x-2 text-gray-600">
                  <Database className="w-5 h-5" />
                  <span className="font-medium">Big Data Processing</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Projects;