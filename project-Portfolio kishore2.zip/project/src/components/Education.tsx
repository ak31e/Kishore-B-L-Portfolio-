import React from 'react';
import { GraduationCap, Award, BookOpen } from 'lucide-react';

const Education = () => {
  const educationData = [
    {
      degree: 'B.E. Electronics and Communication Engineering',
      institution: 'GRT Institute of Engineering & Technology',
      period: '2019 – 2023',
      grade: 'CGPA: 7.73',
      icon: GraduationCap,
      color: 'bg-blue-600'
    },
    {
      degree: '12th Grade',
      institution: 'Govt. Boys Hr. Sec. School, Podaturpet',
      period: 'Completed',
      grade: '53%',
      icon: BookOpen,
      color: 'bg-green-600'
    },
    {
      degree: '10th Grade',
      institution: 'Govt. Boys Hr. Sec. School, Podaturpet',
      period: 'Completed',
      grade: '73%',
      icon: Award,
      color: 'bg-purple-600'
    }
  ];

  return (
    <section id="education" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Education
          </h2>
          <div className="w-20 h-1 bg-blue-600 rounded-full mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Academic foundation in engineering and technology
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="space-y-8">
            {educationData.map((edu, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
              >
                <div className="flex items-start space-x-6">
                  <div className={`flex-shrink-0 w-16 h-16 ${edu.color} rounded-2xl flex items-center justify-center`}>
                    <edu.icon className="w-8 h-8 text-white" />
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                      <h3 className="text-xl md:text-2xl font-bold text-gray-900 mb-2 md:mb-0">
                        {edu.degree}
                      </h3>
                      <div className="flex items-center space-x-4">
                        <span className="px-4 py-2 bg-blue-50 text-blue-700 rounded-full font-medium text-sm">
                          {edu.period}
                        </span>
                        <span className="px-4 py-2 bg-green-50 text-green-700 rounded-full font-medium text-sm">
                          {edu.grade}
                        </span>
                      </div>
                    </div>
                    
                    <p className="text-lg text-gray-600 font-medium">
                      {edu.institution}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Education;