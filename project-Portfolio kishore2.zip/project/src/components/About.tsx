import React from 'react';

const About = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Profile Image */}
          <div className="relative">
            <div className="aspect-[4/5] rounded-3xl overflow-hidden shadow-2xl">
              <img
                src="/src/assets/P3.png"
                alt="Kishore B L - Profile"
                className="w-full h-full object-cover object-center"
              />
            </div>
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-blue-600 rounded-full opacity-10"></div>
            <div className="absolute -top-6 -left-6 w-24 h-24 bg-purple-600 rounded-full opacity-10"></div>
          </div>

          {/* Content */}
          <div className="space-y-8">
            <div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
                About Me
              </h2>
              <div className="w-20 h-1 bg-blue-600 rounded-full mb-8"></div>
            </div>
            
            <div className="prose prose-lg text-gray-600 leading-relaxed">
              <p className="text-xl leading-relaxed">
                I'm a creative and detail-focused UI/UX designer and content creator with experience in website development using WordPress and Wix Studio. I specialize in designing desktop UIs, posters, icons, and logos using Figma and Adobe Illustrator.
              </p>
              <p className="text-xl leading-relaxed mt-6">
                I've trained teams in AI tools and built digital experiences with storytelling at the core, combining technical expertise with creative vision to deliver impactful solutions.
              </p>
            </div>

            <div className="flex flex-wrap gap-4 pt-6">
              {['UI/UX Design', 'Web Development', 'Content Creation', 'Team Training'].map((skill) => (
                <span
                  key={skill}
                  className="px-4 py-2 bg-blue-50 text-blue-700 rounded-full font-medium"
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;