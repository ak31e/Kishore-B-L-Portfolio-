import React from 'react';
import { 
  Figma, 
  Code, 
  Palette, 
  Globe, 
  Cpu, 
  Zap,
  Layers,
  PenTool
} from 'lucide-react';

const ToolIcons = () => {
  const tools = [
    { icon: Figma, color: 'text-purple-400', position: 'top-1/4 left-1/6' },
    { icon: Palette, color: 'text-orange-400', position: 'top-1/3 right-1/5' },
    { icon: Globe, color: 'text-blue-400', position: 'bottom-1/3 left-1/12' },
    { icon: Code, color: 'text-green-400', position: 'top-1/2 left-1/8' },
    { icon: Layers, color: 'text-indigo-400', position: 'bottom-1/4 right-1/8' },
    { icon: PenTool, color: 'text-pink-400', position: 'top-1/5 right-1/3' },
  ];

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-30">
      {tools.map((tool, index) => (
        <div
          key={index}
          className={`absolute ${tool.position} ${
            index % 2 === 0 ? 'animate-float-gentle' : 'animate-float-gentle-reverse'
          }`}
          style={{ animationDelay: `${index * 0.5}s` }}
        >
          <div className="w-10 h-10 bg-white/60 backdrop-blur-sm rounded-xl flex items-center justify-center shadow-sm border border-white/40">
            <tool.icon className={`w-5 h-5 ${tool.color}`} />
          </div>
        </div>
      ))}
    </div>
  );
};

export default ToolIcons;