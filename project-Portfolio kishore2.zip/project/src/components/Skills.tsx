import React from 'react';
import { 
  Figma, 
  Code, 
  Palette, 
  Globe, 
  Cpu, 
  Zap,
  Layers,
  PenTool,
  Briefcase,
  BookOpen
} from 'lucide-react';

const Skills = () => {
  const skillGroups = [
    {
      title: 'Design Tools',
      color: 'bg-purple-50 border-purple-200 text-purple-700',
      skills: [
        { name: 'Figma', icon: Figma },
        { name: 'Adobe Illustrator', icon: Palette },
        { name: 'Bubble.io', icon: Cpu },
      ]
    },
    {
      title: 'Web Platforms',
      color: 'bg-blue-50 border-blue-200 text-blue-700',
      skills: [
        { name: 'WordPress', icon: Globe },
        { name: 'Wix Studio', icon: Layers },
      ]
    },
    {
      title: 'Development',
      color: 'bg-green-50 border-green-200 text-green-700',
      skills: [
        { name: 'HTML', icon: Code },
        { name: 'CSS', icon: Code },
        { name: 'JavaScript', icon: Zap },
      ]
    },
    {
      title: 'AI & Content Tools',
      color: 'bg-orange-50 border-orange-200 text-orange-700',
      skills: [
        { name: 'ChatGPT', icon: PenTool },
        { name: 'Claude', icon: PenTool },
        { name: 'Prompt Engineering', icon: Briefcase },
        { name: 'Articulate 360', icon: BookOpen },
        { name: 'Storyline', icon: BookOpen },
      ]
    }
  ];

  return (
    <section id="skills" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Skills & Expertise
          </h2>
          <div className="w-20 h-1 bg-blue-600 rounded-full mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            A comprehensive toolkit for creating exceptional digital experiences
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {skillGroups.map((group, groupIndex) => (
            <div
              key={group.title}
              className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
            >
              <h3 className="text-xl font-bold text-gray-900 mb-6 text-center">
                {group.title}
              </h3>
              <div className="space-y-4">
                {group.skills.map((skill, skillIndex) => (
                  <div
                    key={skill.name}
                    className={`flex items-center space-x-3 p-3 rounded-xl border-2 ${group.color} transition-all duration-300 hover:scale-105`}
                  >
                    <skill.icon className="w-5 h-5" />
                    <span className="font-medium">{skill.name}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;