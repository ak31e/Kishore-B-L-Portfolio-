import React from 'react';
import { Palette, Layout, Zap, Image } from 'lucide-react';

const Designs = () => {
  const designCategories = [
    {
      title: 'Logos',
      icon: Zap,
      description: 'Brand identity and logo designs',
      color: 'from-purple-400 to-pink-400'
    },
    {
      title: 'Posters',
      icon: Image,
      description: 'Creative poster and print designs',
      color: 'from-blue-400 to-cyan-400'
    },
    {
      title: 'Desktop UI',
      icon: Layout,
      description: 'User interface mockups and designs',
      color: 'from-green-400 to-blue-400'
    },
    {
      title: 'Icon Designs',
      icon: Palette,
      description: 'Custom icon sets and graphics',
      color: 'from-orange-400 to-red-400'
    }
  ];

  return (
    <section id="designs" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            My Visual Work
          </h2>
          <div className="w-20 h-1 bg-blue-600 rounded-full mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            A showcase of creative designs spanning logos, posters, UI mockups, and custom icons
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {designCategories.map((category, index) => (
            <div
              key={category.title}
              className="group relative bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-4"
            >
              {/* Gradient Background */}
              <div className={`absolute inset-0 bg-gradient-to-br ${category.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300`}></div>
              
              {/* Content */}
              <div className="relative p-8 text-center">
                <div className={`inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br ${category.color} mb-6 transform group-hover:scale-110 transition-transform duration-300`}>
                  <category.icon className="w-8 h-8 text-white" />
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-3">
                  {category.title}
                </h3>
                
                <p className="text-gray-600 leading-relaxed">
                  {category.description}
                </p>
              </div>

              {/* Hover Effect */}
              <div className="absolute inset-0 border-2 border-transparent group-hover:border-blue-200 rounded-2xl transition-colors duration-300"></div>
            </div>
          ))}
        </div>

        {/* Coming Soon Notice */}
        <div className="text-center mt-12">
          <div className="inline-flex items-center px-6 py-3 bg-blue-50 text-blue-700 rounded-full font-medium">
            <Palette className="w-5 h-5 mr-2" />
            Design Portfolio Gallery Coming Soon
          </div>
        </div>
      </div>
    </section>
  );
};

export default Designs;