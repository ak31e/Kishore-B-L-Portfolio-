import React from 'react';
import { Linkedin, Github, Dribbble, ArrowDown } from 'lucide-react';
import ToolIcons from './ToolIcons';

const Hero = () => {
  const scrollToAbout = () => {
    const element = document.getElementById('about');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-white via-gray-50/30 to-indigo-50/20">
      {/* Subtle Background Elements */}
      <ToolIcons />
      
      {/* Main Content */}
      <div className="relative z-10 max-w-6xl mx-auto px-6 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          {/* Text Content - Left Side */}
          <div className="space-y-8 text-center lg:text-left animate-fade-in-up">
            {/* Greeting */}
            <div className="space-y-6">
              <p className="text-indigo-600 font-light text-lg tracking-wide">
                Hi there,
              </p>
              
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-semibold text-gray-900 leading-tight text-balance">
                I'm Kishore B L
              </h1>
              
              <p className="text-xl md:text-2xl text-gray-500 font-light leading-relaxed">
                UI/UX Designer · Web Developer · Content Creator
              </p>
            </div>
            
            {/* Description */}
            <div className="max-w-lg">
              <p className="text-gray-600 font-light leading-relaxed text-lg">
                As a passionate UI designer and content creator, I specialize in crafting intuitive user experiences and visual interfaces for web and desktop platforms. I also build WordPress-based websites and train teams in AI tools.
              </p>
            </div>
            
            {/* CTA Button */}
            <div className="pt-4">
              <button
                onClick={scrollToAbout}
                className="btn-primary inline-flex items-center px-8 py-4 text-white font-medium rounded-xl hover-lift"
              >
                Explore My Work
              </button>
            </div>
            
            {/* Social Links */}
            <div className="flex space-x-4 justify-center lg:justify-start pt-6">
              <a
                href="#"
                className="social-icon w-12 h-12 bg-white border border-gray-200 rounded-full flex items-center justify-center text-gray-600 hover:text-indigo-600 hover:border-indigo-200"
              >
                <Linkedin className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="social-icon w-12 h-12 bg-white border border-gray-200 rounded-full flex items-center justify-center text-gray-600 hover:text-indigo-600 hover:border-indigo-200"
              >
                <Github className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="social-icon w-12 h-12 bg-white border border-gray-200 rounded-full flex items-center justify-center text-gray-600 hover:text-indigo-600 hover:border-indigo-200"
              >
                <Dribbble className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Profile Image - Right Side */}
          <div className="flex justify-center lg:justify-end">
            <div className="relative">
              {/* Main Image Container */}
              <div className="image-container relative w-80 h-96 md:w-96 md:h-[30rem] rounded-3xl overflow-hidden shadow-xl bg-white border border-gray-100">
                <img
                  src="/src/assets/P1-BC.png"
                  alt="Kishore B L - UI/UX Designer and Web Developer"
                  className="w-full h-full object-cover object-center"
                />
              </div>
              
              {/* Floating Accent Elements */}
              <div className="absolute -top-6 -left-6 w-24 h-24 bg-gradient-to-br from-indigo-400/20 to-purple-400/20 rounded-full blur-xl animate-float-gentle"></div>
              <div className="absolute -bottom-8 -right-8 w-32 h-32 bg-gradient-to-br from-blue-400/20 to-indigo-400/20 rounded-full blur-xl animate-float-gentle-reverse"></div>
              
              {/* Subtle Border Accent */}
              <div className="absolute inset-0 rounded-3xl border border-white/50 pointer-events-none"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
        <div className="flex flex-col items-center space-y-2 animate-bounce cursor-pointer" onClick={scrollToAbout}>
          <div className="w-px h-8 bg-gradient-to-b from-transparent via-gray-300 to-transparent"></div>
          <div className="w-6 h-6 border border-gray-300 rounded-full flex items-center justify-center">
            <ArrowDown className="w-3 h-3 text-gray-400" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;